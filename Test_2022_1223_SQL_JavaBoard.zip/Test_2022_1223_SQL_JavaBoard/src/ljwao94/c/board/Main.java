package ljwao94.c.board;

import ljwao94.c.site.SiteMain;

public class Main {
	public static void main(String[] args) {
		SiteMain.run();
	}
}