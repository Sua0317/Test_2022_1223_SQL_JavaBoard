package ljwao94.c.board;

import ljwao94.c.board.disp.DispBoard;
import ljwao94.c.util.Ci;
import ljwao94.c.util.Cw;
import ljwao94.c.util.Db;

public class ProcBoard {
	static public void run() {
		DispBoard.title();
//		Db.dbInit();
		Db.getPostCount();
		loop: while (true) {
			Db.dbPostCount();
			DispBoard.menuMain();
			String cmd = Ci.r("해당 번호 입력");
			switch (cmd) {
			case "1": // 글리스트
				ProcList.run();
				break;
			case "2": // 글읽기
				ProcRead.run();
				break;
			case "3": // 글쓰기
				ProcWrite.run();
				break;
			case "4": // 글삭제
				ProcDel.run();
				break;
			case "5": // 글수정
				ProcEdit.run();
				break;
			case "6": // 글리스트-검색
				ProcList.search();
				break;
			case "x": // 프로그램 종료
				Cw.wn("사이트 메인으로 이동");
				break loop;
			default:
				Cw.wn("잘못된 입력입니다.");
				break;
			}
		}
	}
}