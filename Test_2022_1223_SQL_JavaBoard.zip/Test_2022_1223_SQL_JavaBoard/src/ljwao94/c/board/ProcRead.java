package ljwao94.c.board;

import ljwao94.c.util.Ci;
import ljwao94.c.util.Cw;
import ljwao94.c.util.Db;

public class ProcRead {
	static public void run() {
		String readNo = Ci.r("읽을 글 번호를 입력해주세요:");
		try {
			Db.result = Db.st.executeQuery("select * from SQL_JavaBoard_Test where b_no =" + readNo);
			Db.result.next();
			String title = Db.result.getString("b_title");
			String content = Db.result.getString("b_text");
			Cw.wn("글제목: " + title);
			Cw.wn("글내용: " + content);

			// 댓글 리스트 출력 처리
			ProcReply.list(Integer.parseInt(readNo));

			loop: while (true) {
				String cmd = Ci.r("명령[x:나가기,r:댓글쓰기]");
				switch (cmd) {
				case "x":
					break loop;
				case "r":
					ProcReply.write(Integer.parseInt(readNo));
					break;
				default:
					Cw.wn("잘못된 입력입니다.");
				}
			}
		} catch (Exception e) {
		}
	}
}
