package ljwao94.c.board.disp;

import ljwao94.c.util.Cw;

public class DispBoard {
	static private String TITLE = "콘솔게임게시판";
	static private String VERSION = " v0.0.7";
	static private String FEAT = "LEE";
	public static void title() {
		Cw.line();
		Cw.dot();
		Cw.space(20);
		Cw.w(TITLE);
		Cw.w(VERSION);
		Cw.w(FEAT);
		Cw.space(20);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}
	public static void menuMain() {
		Cw.dot();
		Cw.w("[1]글 리스트 [2]글 읽기 [3]글 쓰기 [4]글 삭제 [5]글 수정 [6]검색 [x]게시판 종료");
		Cw.dot();
		Cw.wn();
	}
	static public void titleList() {
		Cw.wn("==========================================");
		Cw.wn("================= 글리스트 ==================");
		Cw.wn("==========================================");
		Cw.wn("글번호 글제목 작성자id 작성시간");
	}
	public static void replyBar() {
		Cw.wn("================= 댓글 리스트 ==================");
	}	
}
