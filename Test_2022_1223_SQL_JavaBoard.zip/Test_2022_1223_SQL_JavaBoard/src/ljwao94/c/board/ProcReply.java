package ljwao94.c.board;

import ljwao94.c.board.disp.DispBoard;
import ljwao94.c.util.Ci;
import ljwao94.c.util.Cw;
import ljwao94.c.util.Db;

public class ProcReply {
	static public void list(int oriNo) {
		DispBoard.replyBar();
		String sql = "select * from SQL_JavaBoard_Test where b_reply_ori=" + oriNo;
		try {
			Cw.wn("전송한sql문:" + sql);
			Db.result = Db.st.executeQuery(sql);
			while (Db.result.next()) {
				String b_reply_text = Db.result.getString("b_reply_text");
				Cw.wn(b_reply_text);
				String b_reply_id = Db.result.getString("b_reply_id");
				Cw.wn(b_reply_id);
			}
		} catch (Exception e) {
		}
	}
	static public void write(int b_reply_ori) {
		String b_reply_text = Ci.rl("댓글 입력");
		String b_reply_id = Ci.rl("댓글작성자 id입력");
		Db.dbExecuteUpdate("insert into SQL_JavaBoard_Test (b_id,b_datetime,b_reply_ori,b_reply_text,b_reply_id) values('댓글러',now(),"+ b_reply_ori + ",'" + b_reply_text + "','" + b_reply_id + "')");
	}
}
