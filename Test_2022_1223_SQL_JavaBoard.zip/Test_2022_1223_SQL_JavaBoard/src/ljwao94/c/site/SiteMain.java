package ljwao94.c.site;

import ljwao94.c.board.ProcBoard;
import ljwao94.c.site.display.DispSite;
import ljwao94.c.util.Ci;
import ljwao94.c.util.Cw;
import ljwao94.c.util.Db;

public class SiteMain {
	static private String cmd = "";

	static public void run() {
		Db.dbInit();
		loop: while (true) {
			DispSite.entraceTitle();
			cmd = Ci.r("[r]회원가입 [1]로그인 [a]관리자 [e]프로그램 종료 [b]게시판(비회원 로그인)");
			switch (cmd) {
			case "r":
				// 추후업데이트
				break;
			case "1":
				// 추후업데이트
				break;
			case "a":
				// 추후업데이트
				break;
			case "e":
				Cw.wn("프로그램 종료");
				break loop;
			case "b":
				ProcBoard.run();
				break;
			default:
				Cw.wn("잘못된 입력입니다.");
			}
		}
	}
}
