package ljwao94.c.site.display;

import ljwao94.c.util.Cw;

public class DispSite {
	static private String SITE_NAME = "ljwao94";
	static private String VERSION = "v0.0.0";
	static private String Feat = "LEE";

	static public void entraceTitle() {
		Cw.line();
		Cw.dot();
		Cw.space(22);
		Cw.w(SITE_NAME);
		Cw.w(VERSION);
		Cw.w(Feat);
		Cw.space(22);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}
}