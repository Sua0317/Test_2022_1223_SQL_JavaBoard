/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module sql_java {
	requires java.sql;
}